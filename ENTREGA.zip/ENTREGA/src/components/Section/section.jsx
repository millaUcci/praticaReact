import styles from "./section.module.css";
import Plan from '../Plan/plan';

 
export default function Advertisement({text, button, color}) {
 
    return (
        <section className={styles.section}>
            <div className={styles.div}>
                <h1 className={styles.h1}>{text}</h1>
    
                <button className={styles.button} style={{background: color}}>{button}</button>

                <div className={styles.plans}>
                    <Plan
                        title="FREE"
                        price= "0"
                        color= {color}
                    />
                    <Plan
                        title="PREMIUM"
                        price= "99"
                        color= {color}
                    />
                    <Plan
                        title="PRO"
                        price= "199"
                        color= {color}
                    />
                </div>
            </div>
        </section>
    );
}
