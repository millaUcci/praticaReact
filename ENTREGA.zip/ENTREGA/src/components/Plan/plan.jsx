import styles from "./plan.module.css";
 
export default function Plan({title, price, color}) {
 
    return (
        <div className={styles.card}>
            <h1 className={styles.h1}>{title}</h1>
            <p>PNG templates</p>
            <p>Figma responsive
            components</p>
            <p>Constant updates</p>
            <p>Custom templates</p>
           
            <div className={styles.itemDetails}>
                <h3 className="price">R$ {price}</h3>
                <p className="per">Per month</p>
                <button style={{backgroundColor: color}} className={styles.button}>Try Now</button>
            </div>
        </div>
    );
}
