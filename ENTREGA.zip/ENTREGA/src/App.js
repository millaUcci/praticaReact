import Section from './components/Section/section';

import './App.css';

function App() {
  return (
    <div className="App">
      <Section
        text="PLANS +"
        button="red"
        color="#FF0000"
      />
      <Section
        text="NEW MEMBER"
        button="green"
        color="#008000"
      />
    </div>
  );
}

export default App;
